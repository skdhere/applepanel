<?php

include_once("xlsxwriter.class.php");


/**
* 
*/
class ClassName 
{
	
	function __construct(argument)
	{
		# code...
	}
}

?>